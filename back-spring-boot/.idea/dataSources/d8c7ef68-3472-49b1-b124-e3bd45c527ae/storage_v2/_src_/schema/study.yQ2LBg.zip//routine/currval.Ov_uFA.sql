create
    definer = root@localhost function currval(the_name varchar(20)) returns bigint unsigned deterministic
begin
		declare ret bigint unsigned;
        	select currval into ret from sequences where name = the_name limit 1;
		return ret;
	end;

